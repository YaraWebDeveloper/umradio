<?php

require APPPATH . '/libraries/REST_Controller.php';

/**
 * Controlador general para el server de RYM
 * Desde aqui se aplican todas las configuraciones para el webservice
 *
 * @package         xr
 * @subpackage      Core
 * @category        Controller
 * @author          Yara Web Developer
 * @license         GPL
 * @version         1.0
 */
class Private_Controller extends REST_Controller {

    /**
     * Contructor de la clase
     * Permite solicitudes CORS (desde otras url, servidores o dominios)
     * 
     * @access public
     */
    public function __construct() {
        //Declarar los header para permitir solicirudes desde cualquier servidor
        header('Access-Control-Allow-Origin: *');
        //Nombre de API Key, debe ser configurada en config/rest.php -> REST API Key Variable
        header("Access-Control-Allow-Headers: accept-auth");
        //Permitir acceso por solicitud option
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == "OPTIONS")
            die();
        //Hacer llamado de contructor padre
        parent::__construct();
    }

}
