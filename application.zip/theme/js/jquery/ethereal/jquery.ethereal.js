/* 
 * Copyright (c) 2015 YARA WEB-DEVELOPER
 * 
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 * 
 * Ethereal
 * V. 1.0
 * 
 */
(function () {
    /*
     * 
     * @param urlView Es la url donde se encuentran alamacenadas las vistas
     */
    var conf_ = {
        urlView: ""
    };
    /*Variable para registrar controladores en el sistema
     */
    var controllers = new Array();
    //métodos de etereal ethereal
    var methods = {
        init: function (conf_user) {
            //opciones sin parametros
            conf_ = $.extend(conf_, conf_user);
            return this;
        }
    };
    /**
     * Inicializador de ethereal
     * Determina los métodos que se ejecutarán
     */
    $.fn.ethereal = function (method) {
        // Si existe la función la llamamos
        if (methods[method]) {
            return methods[ method ]
                    .apply(this,
                            Array.prototype.slice.call(arguments, 1)
                            );
        } else if (typeof method === 'object' || !method) {
            //Si no se pasa ningún parámetro o el parámetro es 
            //un objeto de configuración llamamos al inicializador	
            return methods.init.apply(this, arguments);
        } else {
            //En el resto de los casos mostramos un error
            $.error('La función ' + method
                    + ' no existe en $.ethereal');
        }
    };
    /**
     * Configuraciones como:
     * urlView: url del dominio donde se van a almacenar las vistas de la aplicacion
     */
    $.fn.ethereal().config = function (conf_user) {
//configuraciones principales para ejcutar ethereal
        conf_ = $.extend(conf_, conf_user);
        //ejecutar basicos
        return this;
    };
    /**
     *     
     * Creacion de un controller   
     * @param Object conf_controller
     * @returns $ Object
     */
    $.fn.ethereal().controller = function (conf_controller) {
//realzar extends
//var data = _getData(conf_controller);
        if (!$.isPlainObject(conf_controller)) {
            return controllers[conf_controller];
        }
        var _conf_controller;
        this.each(function () {
            //Datos de ejecucion ethereal
            var _conf_ejecucion = {
                controller: null,
                view: null,
                url: null,
                json: null,
                html: null,
                type: "GET",
                limit: null,
                parent: null,
                add: true,
                refresh: false,
                timeOut: 0,
                onEvent: new Array(),
                params: {},
                done: function () {
                },
                fail: function () {
                },
                always: function () {
                },
                beforeSend: function () {
                }
            };
            //variable de configuracion del controlador
            _conf_controller = $.extend(_conf_ejecucion, conf_controller);
            //console.log(conf_controller);
            //recgistrar controller
            controllers[_conf_controller.controller] = _conf_controller;
            _addEvent(_conf_controller);
            if (_conf_controller.add) {
                if (_conf_controller.url) {
                    getData(_conf_controller);
                    console.log(controllers[_conf_controller.controller]);
                } else {
                    //console.log(_conf_controller);
                    _showData(_conf_controller.json, _conf_controller);
                }
            }
            //console.log(controllers);
        });
        //retornar controller
        return this;
    };
//Configuración inicial
    var _conf_ejecucion = {
        controller: null,
        view: null,
        url: null,
        json: null,
        html: null,
        type: "GET",
        limit: null,
        parent: null,
        add: true,
        timeOut: 0,
        onEvent: new Array(),
        params: {},
        done: function () {
        },
        fail: function () {
        },
        always: function () {
        },
        beforeSend: function () {
        }
    };
    /**
     * 
     * @param {type} _conf_controller
     * @returns {jquery.ethereal_L11}
     */
    function _addEvent(_conf_controller) {
        //variable de controlador
        //obtener la configuracion de los controladores
        var conf_controller = new Object($.extend(_conf_ejecucion, _conf_controller));
        conf_controller.add = true;
        //variables de los eventos
        var events = new Array();
        //var click = controller.onEvent.click;
        $.each(conf_controller.onEvent, function (_conf_event, event) {
            //verificar si llama un evnto adicional
            var _con_element = new Array();
            //verificar la vatriable
            if ($.isArray(event)) {
                //alert(":v");
                if (!$.isEmptyObject(event)) {
                    _con_element = event;
                }
            } else {
                _con_element = event.split(",");
            }
            $.each(_con_element, function (i, data) {
                //elementos
                var element = data.split("~");
                var _data_function = new Array();
                if (element[1]) {
                    _data_function = element[1].split("+");
                }
                //consola
                events[_conf_event] = function () {
                    var conf_controller = new Object($.extend(_conf_ejecucion, _conf_controller));
                    conf_controller.add = true;
                    //console.log(controller);
                    $.each(_data_function, function (i, data) {
                        var _final_function = null;
                        //console.log(data);
                        if ($.isFunction(conf_controller[data])) {
                            _final_function = conf_controller[data];
                        }
                        if ($.isPlainObject(conf_controller[data])) {
                            //alert("JUM")
                            var dataEvent = {
                                on: function () {
                                }
                            };
                            _final_function = $.extend(dataEvent, conf_controller[data]).on;
                            conf_controller = new $.extend(conf_controller, conf_controller[data]);
                        }
                        _final_function();
                    });
                    // getData(conf_controller);
                    if (conf_controller.json) {
                        _showData(conf_controller.json, conf_controller);
                    } else {
                        getData(conf_controller);
                    }
                };
                $(element[0]).on(events);
            });
        });
        return this;
    }


    /******- ---------------Funciones propias del plugin----------------------*******/
    /**
     * Funcion get data para determinar el tipo de solicitud
     * @param javascriptObject _conf_controller
     */
    function getData(_conf_controller) {
        var dataRequest = null;
        var dataValue = null;
        dataRequest = $.ajax({
            url: _conf_controller.url,
            type: _conf_controller.type,
            data: _conf_controller.params,
            dataType: "json",
            beforeSend: _conf_controller.beforeSend()
        });
        dataRequest.done(function (data) {
            _showData(data, _conf_controller);
            //dataValue = data;
            controllers[_conf_controller.controller]['data'] = data;
            //console.log(controllers[_conf_controller.controller]);
        });
        dataRequest.fail(function (data) {
            if ($.isFunction(_conf_controller.fail)) {
                //ejecutar callback
                _conf_controller.fail(data);
            }
            if (data.status === 404)
                alert(data.status + ': Ethereal no puedo acceder a la url especificada');
        });
        dataRequest.always(function () {
            _conf_controller.always();
        });
        return this;
    }

    /**
     * Funcion para iterar la vista y mostrar los datos
     * 
     * @param Object datos Es el json de los datos que se van a iterar
     */
    function _showData(datos, _conf_controller) {
        //
        if (_conf_controller.html) {
            _pushHtml(_conf_controller.html, _conf_controller, datos);
        }
        if (_conf_controller.view) {
            //objeto para obtener la vista
            var viewRequest = $.post(conf_.urlView + _conf_controller.view);
//objeto de success
            viewRequest.done(function (views) {
                //si existe se añade los datoscon
                //_pushHtml(views);
                var html = _pushHtml(views, _conf_controller, datos);
                //ejecutar callback de done
                if ($.isFunction(_conf_controller.done)) {
                    //ejecutar el callback
                    _conf_controller.done(datos, html, _conf_controller.controller + "-view");
                }
            });
            //objeto fail
            viewRequest.fail(function (dataView) {
                if ($.isFunction(_conf_controller.fail)) {
                    //ejecutar callback
                    _conf_controller.fail(dataView);
                }
                if (dataView.status === 404)
                    alert(dataView.status + ': Ethereal no puedo encontrar la vista especificada');
            });
            //vista
        } else {
            //ejecutar callback de done
            if ($.isFunction(_conf_controller.done)) {
                //ejecutar el callback
                _conf_controller.done(datos, _conf_controller.controller + "-view");
            }
        }
        return this;
    }

    //Poner el html
    function _pushHtml(views, _conf_controller, datos) {
        var html;
        if (datos) {
            //Realizar el templte de los datso
            var template = Handlebars.compile(views);
            //convertir el htlml
            if (_conf_controller.limit) {
                var newData = new Array();
                var limite = _conf_controller.limit.toString().split("-");
                if (!limite[1]) {
                    limite[1] = limite[0];
                    limite[0] = "0";
                }
                var count = 0;
                $.each(datos, function (i, data) {
                    if (i >= limite[0]) {
                        newData[count] = data;
                        count++;
                        //var count = parseInt((i * 1) + 1);
                        //console.log(count);
                        datos = newData;
                        if (i >= limite[1]) {
                            return false;
                        }
                    }
                });
            }
            html = $(template(datos));
            html.removeAttr('type');
        } else {
            if ($.isPlainObject(views)) {
                html = views.html();
            } else {
                html = $(views);
            }
        }
        //tratar los html
        // console.log(_conf_controller.controller);
        html.addClass(_conf_controller.controller + "-view");
        if (_conf_controller.add === true) {
            //si hay un parent
            setTimeout(function () {
                if (_conf_controller.parent) {
                    $(_conf_controller.parent).append(html);
                    //console.log(_conf_controller);
                } else {
                    $('body').append(html);
                }
            }, _conf_controller.timeOut);
        }
        return html;
    }

    /**/
})($);