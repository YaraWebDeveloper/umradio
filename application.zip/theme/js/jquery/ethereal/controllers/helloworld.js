$(document).ready(function () {
    $.ajax(
            {url: "http://noderest.pro/api/example/users"
            }
    ).done(function (data) {
        console.log(data);
    }).fail(function (data) {
        console.log(data);
    });
});