//determino el objeto etherealk
var ethereal = $(document).ethereal();
//configurar mi ethereal
ethereal.config({
    urlView: "http://www.ethereal.pro/theme/js/jquery/ethereal/views/"
});
//Creacion de controllador de lista
//jQuery("#lista-nombres").empty();
ethereal.controller({
    controller: "lista_nombres",
    view: "table-usuario.html",
    //url: "http://" + document.domain + "/inicio/mostrarnombres",
    url: "http://noderest.pro/api/example/users",
    parent: "#lista-nombres",
    add: true,
    onEvent: {
        click: ["#names input~hello+reset+nuevafuncion", "#plug~functionRara", "#animales~reset"]
    },
    done: function (dataJson, view, id) {
        $('.load').fadeOut("slow");
    },
    fail: function (data) {
    },
    beforeSend: function () {
        $("#lista-nombres").append("<p class='load'>Loading...</p>");
    },
    always: function () {
    },
    reset: function () {
        //$(ethereal.controller('lista_nombres').parent).empty();
    },
    hello: {
        limit: "3-9"
    },
    functionRara: {
        limit: "4-4",
        on: function () {
            $(".lista-animales").empty();
            //alert("Soy un puto Dios!!");
        }
    },
    nuevafuncion: function(){
       console.log("Ejecuto ethereal"); 
    }
});

